import java.util.Scanner;
abstract class Converter {
	abstract protected double convert(double src);
	abstract protected String getSrcString();
	abstract protected String getDestString();
	protected double ratio;
	
	public void run() {
		Scanner scanner = new Scanner(System.in);
		System.out.println(getSrcString()+"�� "+getDestString()+"�� �ٲߴϴ�.");
		System.out.print(getSrcString()+"�� �Է��ϼ��� >> ");
		double val = scanner.nextDouble();
		double res = convert(val);
		System.out.println("��ȯ ��� : "+res+getDestString()+"�Դϴ�.");
		scanner.close();
	}
}
class Km2Mile extends Converter{
	double src;
	public Km2Mile (double src) {this.src=src;}
	public String getSrcString() {return "Km";}
	public String getDestString() {return "mile";}
	public double convert(double k) {
	return k*(src);
	}
	
}
public class num_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Km2Mile toMile = new Km2Mile(0.62);
		toMile.run();
	}

}
