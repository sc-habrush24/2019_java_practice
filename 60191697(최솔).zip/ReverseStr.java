import java.util.Scanner;
import java.util.Vector;
public class ReverseStr {
	public static String reverseStr(String str) {
		Scanner scanner =new Scanner(System.in);
		char[] chars = str.toCharArray();
		char[] ans = new char [str.length()];
		for(int i=chars.length-1;i>-1;i--) {
			ans[chars.length-i-1]=chars[i];
		}
		chars=ans;
		scanner.close();
		return new String(chars);	
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner =new Scanner(System.in);
		System.out.print("���ܾ �Է��ϼ��� : ");
		String str = scanner.next();
		System.out.print("�Ųٷ� �� �ܾ�� : "+reverseStr(str));
		scanner.close();
	}

}
